
<?php $__env->startSection('content'); ?>
    

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-md">
      <a class="navbar-brand" href="#">Muhammad Afiat Juniardi</a>
    </div>
  </nav>
  <div class="container text-center mt-w-3">
  <div class="card" style="width: 18rem;">
    <img src="https://3.bp.blogspot.com/-aRRq3IOoNzE/VX3VDrTMUjI/AAAAAAAAHdY/Un798DjHrPc/w640/rumah%2Bmakan%2Bbumbu%2Bdesa%2Bdi%2Bbandung.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Warung Afiat Bumbu Desa</h5>
      <p class="card-text">Klik Button Dibawah Untuk Masuk ke Menu Pemesanan</p>
      <a href="<?php echo e(url('/product')); ?>" class="btn btn-primary">Masuk</a>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRUD27\resources\views/awal.blade.php ENDPATH**/ ?>